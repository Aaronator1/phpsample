<html>

<?php
/**
 * Created by PhpStorm.
 * User: aaronmsmith
 * Date: 12/3/15
 * Time: 6:53 AM
 */

 echo "This is going to be a page with control statements."
?>

</html>