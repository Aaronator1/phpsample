<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
	 There should be php now. <BR/>
 <?php echo '<p>Hello World</p>'; ?> 
 </body>
</html>